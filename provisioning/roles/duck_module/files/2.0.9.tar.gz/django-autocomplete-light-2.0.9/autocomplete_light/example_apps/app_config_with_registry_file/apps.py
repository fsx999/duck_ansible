from django.apps import AppConfig


class AppConfigWithRegistryFile(AppConfig):
    name = 'autocomplete_light.example_apps.app_config_with_registry_file'
