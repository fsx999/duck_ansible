from tagging.models import Tag

import autocomplete_light


autocomplete_light.register(Tag)
