import autocomplete_light

from .models import HasVotes



