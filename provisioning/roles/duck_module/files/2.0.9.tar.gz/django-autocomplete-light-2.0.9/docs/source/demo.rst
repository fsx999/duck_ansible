.. include:: ../../test_project/README.rst

.. include:: ../../test_remote_project/README.rst
