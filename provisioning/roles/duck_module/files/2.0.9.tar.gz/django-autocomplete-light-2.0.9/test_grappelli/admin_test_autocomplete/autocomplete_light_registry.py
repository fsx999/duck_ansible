import autocomplete_light

from models import Foo, Bar

autocomplete_light.register(Foo)
autocomplete_light.register(Bar)
